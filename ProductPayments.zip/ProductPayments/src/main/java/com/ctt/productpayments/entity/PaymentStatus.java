package com.ctt.productpayments.entity;

public enum PaymentStatus {
	
	APPROVED, 
	WAITING, 
	REPROVED	

}
