package com.ctt.productpayments.entity;

public enum PaymentType {
	
	DEBIT,	
	CREDIT
	
}
