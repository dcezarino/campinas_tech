package com.ctt.productpayments;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductPaymentsApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductPaymentsApplication.class, args);
	}

}
